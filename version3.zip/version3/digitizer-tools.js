/**********************
 * DIGITIZER TOOLS
 * Handles: mouse interactions, auto-trace, snap-to-line,
 *          point actions, line management, import/export
 *
 * Depends on: digitizer-core.js (must be loaded first)
 **********************/

/**********************
 * SNAP-TO-DARK-PIXEL (MAGNET)
 * Searches a radius around (cx, cy) in canvas coords for the darkest
 * pixel cluster centroid. Used for manual point placement when snapToLine=true,
 * AND applied to every point produced by the highlight pipeline.
 **********************/
const SNAP_RADIUS_CANVAS = 18; // canvas pixels — scaled to image space internally

function snapToDark(cx, cy, forceSnap = false) {
  if (!rawImageData || (!snapToLine && !forceSnap)) return { x: cx, y: cy };
  const { ix, iy } = canvasToImageCoords(cx, cy);
  const iw = rawImageData.width;
  const ih = rawImageData.height;
  const r  = Math.max(4, Math.round(SNAP_RADIUS_CANVAS * (iw / canvas.width)));

  // First pass: find minimum luma in search circle
  let minLuma = 255;
  for (let dy = -r; dy <= r; dy++) {
    for (let dx = -r; dx <= r; dx++) {
      if (dx * dx + dy * dy > r * r) continue;
      const px = Math.round(ix) + dx;
      const py = Math.round(iy) + dy;
      if (px < 0 || py < 0 || px >= iw || py >= ih) continue;
      const idx  = (py * iw + px) * 4;
      const luma = 0.299 * rawImageData.data[idx] + 0.587 * rawImageData.data[idx+1] + 0.114 * rawImageData.data[idx+2];
      if (luma < minLuma) minLuma = luma;
    }
  }

  // Nothing dark enough to snap to
  if (minLuma > 230) return { x: cx, y: cy };

  // Second pass: centroid of pixels within 30 luma of the minimum
  let darkX = 0, darkY = 0, darkCount = 0;
  const threshold = minLuma + 30;
  for (let dy = -r; dy <= r; dy++) {
    for (let dx = -r; dx <= r; dx++) {
      if (dx * dx + dy * dy > r * r) continue;
      const px = Math.round(ix) + dx;
      const py = Math.round(iy) + dy;
      if (px < 0 || py < 0 || px >= iw || py >= ih) continue;
      const idx  = (py * iw + px) * 4;
      const luma = 0.299 * rawImageData.data[idx] + 0.587 * rawImageData.data[idx+1] + 0.114 * rawImageData.data[idx+2];
      if (luma <= threshold) { darkX += px; darkY += py; darkCount++; }
    }
  }

  if (darkCount === 0) return { x: cx, y: cy };

  return {
    x: (darkX / darkCount) * (canvas.width  / iw),
    y: (darkY / darkCount) * (canvas.height / ih)
  };
}

/**********************
 * AUTO-TRACE ENGINE
 *
 * Strategy: perpendicular cross-section sampling.
 * For each interpolated point along the highlight path:
 *   1. Compute the local tangent direction from neighboring path points.
 *   2. Scan pixels perpendicular to that tangent across a search band.
 *   3. Find the centroid of pixels that match the detected line color.
 *   4. That centroid is the refined point — it locks onto the actual line
 *      centre regardless of cursor wobble or grid interference.
 *
 * Line color detection: sample pixels along the raw path, build a color
 * histogram quantised to 32-level buckets, skip near-white buckets
 * (background/grid), pick the most-frequent remaining bucket.
 **********************/

function detectLineColor(pathPoints) {
  if (!rawImageData || pathPoints.length < 2) return null;
  const iw   = rawImageData.width;
  const ih   = rawImageData.height;
  const step = Math.max(1, Math.floor(pathPoints.length / 300));
  const buckets = {};

  for (let i = 0; i < pathPoints.length; i += step) {
    const { ix, iy } = canvasToImageCoords(pathPoints[i].x, pathPoints[i].y);
    const px = Math.round(Math.max(0, Math.min(ix, iw - 1)));
    const py = Math.round(Math.max(0, Math.min(iy, ih - 1)));
    const idx = (py * iw + px) * 4;
    const r = rawImageData.data[idx];
    const g = rawImageData.data[idx + 1];
    const b = rawImageData.data[idx + 2];
    const luma = 0.299 * r + 0.587 * g + 0.114 * b;
    // Skip near-white (background) and near-transparent
    if (luma > 220) continue;
    const key = `${r >> 5},${g >> 5},${b >> 5}`;
    if (!buckets[key]) buckets[key] = { rSum: 0, gSum: 0, bSum: 0, count: 0, lumaSum: 0 };
    buckets[key].rSum += r; buckets[key].gSum += g; buckets[key].bSum += b;
    buckets[key].lumaSum += luma; buckets[key].count++;
  }

  const candidates = Object.values(buckets).sort((a, b) => b.count - a.count);
  if (!candidates.length) return null;

  const best = candidates[0];
  return {
    r: Math.round(best.rSum / best.count),
    g: Math.round(best.gSum / best.count),
    b: Math.round(best.bSum / best.count),
    luma: best.lumaSum / best.count
  };
}

/**
 * Perpendicular scan: given a canvas point (cx,cy), tangent direction (tx,ty),
 * and target color, scan ±bandPx perpendicular pixels in image space and
 * return the centroid of pixels matching the target color.
 */
function refinePerp(cx, cy, tx, ty, targetColor, bandPx) {
  if (!rawImageData || !targetColor) return { x: cx, y: cy };
  const iw  = rawImageData.width;
  const ih  = rawImageData.height;
  const { ix, iy } = canvasToImageCoords(cx, cy);

  // Perpendicular direction (normalized)
  const len = Math.hypot(tx, ty) || 1;
  const px_dir = -ty / len;  // perpendicular x
  const py_dir =  tx / len;  // perpendicular y

  // Scale canvas-pixel band to image pixels
  const imgBand = Math.max(3, Math.round(bandPx * (iw / canvas.width)));

  // Tolerance: how different a pixel can be from target color to still "match"
  const tol = 55;

  let sumX = 0, sumY = 0, count = 0;

  for (let s = -imgBand; s <= imgBand; s++) {
    const sx = Math.round(ix + px_dir * s);
    const sy = Math.round(iy + py_dir * s);
    if (sx < 0 || sy < 0 || sx >= iw || sy >= ih) continue;
    const idx = (sy * iw + sx) * 4;
    const dr  = rawImageData.data[idx]     - targetColor.r;
    const dg  = rawImageData.data[idx + 1] - targetColor.g;
    const db  = rawImageData.data[idx + 2] - targetColor.b;
    const dist = Math.sqrt(dr*dr + dg*dg + db*db);
    if (dist < tol) { sumX += sx; sumY += sy; count++; }
  }

  if (count === 0) return { x: cx, y: cy };  // no match — stay put
  return {
    x: (sumX / count) * (canvas.width  / iw),
    y: (sumY / count) * (canvas.height / ih)
  };
}

/**
 * Full auto-trace pipeline:
 *  1. Detect dominant line color from raw path pixels (skip near-white)
 *  2. Interpolate n evenly-spaced points along the raw path
 *  3. For each point, compute local tangent from neighbors in the path
 *  4. Scan perpendicularly to find color-matched centroid
 *  5. Apply snap-to-dark on top as a secondary refinement
 */
function autoTrace(pathPoints, n) {
  showSpinner(true);
  const lineColor = detectLineColor(pathPoints);
  const spaced    = interpolatePoints(pathPoints, n);
  // Band in canvas pixels — generous to handle wobble in tracing
  const BAND_CANVAS = 18;

  const refined = spaced.map((p, i) => {
    // Compute local tangent using neighbors
    const prev = spaced[Math.max(0, i - 1)];
    const next = spaced[Math.min(spaced.length - 1, i + 1)];
    const tx   = next.x - prev.x;
    const ty   = next.y - prev.y;

    let pt = lineColor
      ? refinePerp(p.x, p.y, tx, ty, lineColor, BAND_CANVAS)
      : { x: p.x, y: p.y };

    // Secondary: snap to dark centroid (forceSnap=true — ignores toggle state)
    pt = snapToDark(pt.x, pt.y, true);
    return pt;
  });

  showSpinner(false);
  return { refined, lineColor };
}

/**********************
 * POINT INTERPOLATION
 **********************/
function interpolatePoints(points, n) {
  if (points.length < 2) return points;
  const result = [];
  const totalLength = points.reduce((sum, p, i) => {
    if (i === 0) return 0;
    return sum + Math.hypot(p.x - points[i - 1].x, p.y - points[i - 1].y);
  }, 0);
  if (totalLength === 0) return [points[0]];

  const segLen = totalLength / (n - 1);
  let   accLen = 0;
  result.push(points[0]);

  for (let i = 1; i < points.length && result.length < n; i++) {
    const dx  = points[i].x - points[i - 1].x;
    const dy  = points[i].y - points[i - 1].y;
    const seg = Math.hypot(dx, dy);
    accLen += seg;
    while (result.length < n && accLen >= segLen * result.length) {
      const t = (segLen * result.length - (accLen - seg)) / seg;
      result.push({ x: points[i - 1].x + t * dx, y: points[i - 1].y + t * dy });
    }
  }
  return result.slice(0, n);
}

/**********************
 * CANVAS MOUSE EVENTS
 **********************/
canvas.addEventListener('mousedown', e => {
  if (isPanning && e.buttons === 1) {
    startPan.x = e.clientX - panX;
    startPan.y = e.clientY - panY;
    return;
  }

  let { x, y } = imageToCanvasCoords(e.clientX, e.clientY);

  // Apply orthogonal snapping for axis mode
  if (mode === 'axes' && orthogonalAxes.checked && axisPoints.length > 0) {
    if (sharedOrigin.checked) {
      if (axisPoints.length === 1) y = axisPoints[0].y;
      else if (axisPoints.length === 2) x = axisPoints[0].x;
    } else {
      if (axisPoints.length === 1) y = axisPoints[0].y;
      else if (axisPoints.length === 3) x = axisPoints[2].x;
    }
  }

  if (e.button === 0 && mode === 'axes') {
    if (sharedOrigin.checked && axisPoints.length === 0) {
      axisPoints.push({ x, y, label: 'Origin (X1/Y1)' });
      axisInstruction.textContent = 'Click point for X2 on the chart.';
    } else if (sharedOrigin.checked && axisPoints.length === 1) {
      axisPoints.push({ x, y, label: 'X2' });
      axisInstruction.textContent = 'Click point for Y2 on the chart.';
    } else if (sharedOrigin.checked && axisPoints.length === 2) {
      axisPoints.push({ x, y, label: 'Y2' });
      axisInstruction.textContent = 'Enter axis values and click Calibrate.';
      calibrateBtn.disabled = false;
    } else if (!sharedOrigin.checked && axisPoints.length < 4) {
      axisPoints.push({ x, y, label: axisLabels[axisPoints.length] });
      if (axisPoints.length < 4) {
        axisInstruction.textContent = `Click point for ${axisLabels[axisPoints.length]} on the chart.`;
      } else {
        axisInstruction.textContent = 'Enter axis values and click Calibrate.';
        calibrateBtn.disabled = false;
      }
    }
    axisInputs.style.display = 'block';
    updateAxisLabels();
    calibrateBtn.disabled = axisPoints.length !== (sharedOrigin.checked ? 3 : 4);
    draw(); saveState(); saveSession();

  } else if (e.button === 0 && mode === 'add' && isCalibrated) {
    // Apply snap-to-dark if enabled (uses snapToLine toggle)
    const snapped   = snapToDark(x, y, false);
    const dataCoords= canvasToDataCoords(snapped.x, snapped.y);
    if (!dataCoords) return;
    const line = lines[currentLineIndex];
    line.points.push({ x: snapped.x, y: snapped.y, dataX: dataCoords.dataX, dataY: dataCoords.dataY, order: ++line.orderCounter });
    updatePreview(); draw(); saveState(); saveSession();

  } else if (e.button === 0 && mode === 'delete' && isCalibrated) {
    const index = findNearestPointIndex(x, y);
    if (index !== -1) {
      lines[currentLineIndex].points.splice(index, 1);
      updatePreview(); draw(); saveState(); saveSession();
    }

  } else if (e.button === 0 && mode === 'adjust' && isCalibrated) {
    selectedPointIndex = findNearestPointIndex(x, y);
    if (selectedPointIndex !== -1) isDraggingPoint = true;

  } else if (e.button === 0 && mode === 'highlight' && isCalibrated && !isHighlighting) {
    isHighlighting = true;
    highlightPath  = [{ x, y }];
    draw();
  }
});

canvas.addEventListener('mousemove', e => {
  let { x, y } = imageToCanvasCoords(e.clientX, e.clientY);
  let dataCoords = isCalibrated ? canvasToDataCoords(x, y) : { dataX: x, dataY: y };
  statusBar.textContent = `Mode: ${mode} | Canvas: (${x.toFixed(1)}, ${y.toFixed(1)}) | Data: (${dataCoords.dataX.toFixed(4)}, ${dataCoords.dataY.toFixed(4)})`;

  // Orthogonal snap in axes mode
  if (mode === 'axes' && orthogonalAxes.checked && axisPoints.length > 0) {
    if (sharedOrigin.checked) {
      if (axisPoints.length === 1) y = axisPoints[0].y;
      else if (axisPoints.length === 2) x = axisPoints[0].x;
    } else {
      if (axisPoints.length === 1) y = axisPoints[0].y;
      else if (axisPoints.length === 3) x = axisPoints[2].x;
    }
  }

  if (['axes', 'add', 'adjust', 'delete', 'highlight'].includes(mode)) {
    drawMagnifier(e.clientX, e.clientY);
  }

  if (isDraggingPoint && mode === 'adjust') {
    const snapped    = snapToDark(x, y, false);
    const dc         = canvasToDataCoords(snapped.x, snapped.y);
    if (!dc) return;
    lines[currentLineIndex].points[selectedPointIndex] = {
      x: snapped.x, y: snapped.y, dataX: dc.dataX, dataY: dc.dataY,
      order: lines[currentLineIndex].points[selectedPointIndex].order
    };
    updatePreview(); draw();
  }

  if (isHighlighting && mode === 'highlight') {
    const last = highlightPath[highlightPath.length - 1];
    if (!last || Math.hypot(x - last.x, y - last.y) > 5 / zoom) {
      highlightPath.push({ x, y });
      draw();
    }
  }
});

canvas.addEventListener('mouseup', e => {
  if (e.button === 0 && mode === 'adjust' && isDraggingPoint) {
    isDraggingPoint    = false;
    selectedPointIndex = -1;
    saveState(); saveSession();

  } else if (e.button === 0 && mode === 'highlight' && isHighlighting) {
    isHighlighting = false;
    if (highlightPath.length < 2) {
      showModal('Highlight path is too short.');
      highlightPath = []; draw(); return;
    }

    const n = parseInt(nPointsInput.value);
    if (isNaN(n) || n <= 0) {
      showModal('Number of points (n) must be a positive integer.');
      highlightPath = []; draw(); return;
    }

    const useAutoTrace = autoTraceCheckbox && autoTraceCheckbox.checked;

    let lineName = (highlightLineName.value.trim()) || `Highlighted Line ${lines.length + 1}`;
    // Ensure unique name
    let suffix = 1;
    const baseName = lineName;
    while (lines.some(l => l.name === lineName)) { lineName = `${baseName} (${suffix++})`; }

    const newLine = { name: lineName, points: [], sorted: false, orderCounter: 0 };
    lines.push(newLine);
    currentLineIndex = lines.length - 1;

    // Get raw interpolated or auto-traced points
    let candidates;
    if (useAutoTrace && rawImageData) {
      const { refined, lineColor } = autoTrace(highlightPath, n);
      candidates = refined;
      const colorDesc = lineColor ? `RGB(${lineColor.r},${lineColor.g},${lineColor.b})` : 'unknown';
      statusBar.textContent = `Auto-trace: ${candidates.length} pts — detected line color ${colorDesc}`;
    } else {
      candidates = interpolatePoints(highlightPath, n);
    }

    // Apply snap-to-dark if checkbox is on (always runs, regardless of auto-trace)
    candidates.forEach(p => {
      const snapped = snapToDark(p.x, p.y, false); // respects snapToLine toggle
      const dc = canvasToDataCoords(snapped.x, snapped.y);
      if (dc) newLine.points.push({ x: snapped.x, y: snapped.y, dataX: dc.dataX, dataY: dc.dataY, order: ++newLine.orderCounter });
    });

    highlightPath = [];
    updateLineSelect(); updatePreview(); draw(); saveState(); saveSession();
  }
});

/**********************
 * IMAGE UPLOAD
 **********************/
imageUpload.addEventListener('change', e => {
  const file = e.target.files[0];
  if (!file) { showModal('No file selected.'); return; }
  const validTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/bmp', 'image/webp'];
  if (!validTypes.includes(file.type)) {
    showModal('Invalid file type. Please upload PNG, JPEG, GIF, BMP or WebP.');
    return;
  }
  const reader = new FileReader();
  reader.onload  = ev => loadImage(ev.target.result);
  reader.onerror = ()  => showModal('Error reading file.');
  reader.readAsDataURL(file);
});

/**********************
 * POINT ACTIONS
 **********************/
addPointBtn.addEventListener('click', () => {
  mode = 'add';
  highlightControls.style.display = 'none';
  updateButtonStates();
});

adjustPointBtn.addEventListener('click', () => {
  mode = 'adjust';
  highlightControls.style.display = 'none';
  updateButtonStates();
});

deletePointBtn.addEventListener('click', () => {
  mode = 'delete';
  highlightControls.style.display = 'none';
  updateButtonStates();
});

highlightLineBtn.addEventListener('click', () => {
  mode = 'highlight';
  highlightControls.style.display = 'block';
  axisInputs.style.display        = 'none';
  updateButtonStates();
});

deleteHighlightBtn.addEventListener('click', () => {
  highlightPath = [];
  draw(); saveState(); saveSession();
});

clearPointsBtn.addEventListener('click', () => {
  lines[currentLineIndex].points       = [];
  lines[currentLineIndex].orderCounter = 0;
  lines[currentLineIndex].sorted       = false;
  sortPointsBtn.classList.remove('sort-active');
  updatePreview(); draw(); saveState(); saveSession();
});

sortPointsBtn.addEventListener('click', () => {
  const line = lines[currentLineIndex];
  line.sorted = !line.sorted;
  sortPointsBtn.classList.toggle('sort-active', line.sorted);
  updatePreview(); draw(); saveState(); saveSession();
});

/**********************
 * LINE MANAGEMENT
 **********************/
newLineBtn.addEventListener('click', () => {
  showModal('Enter new line name:', true, name => {
    if (!name) { showModal('Line name cannot be empty'); return; }
    if (lines.some(l => l.name === name)) { showModal('Line name must be unique'); return; }
    lines.push({ name, points: [], sorted: false, orderCounter: 0 });
    currentLineIndex = lines.length - 1;
    updateLineSelect(); updatePreview(); draw(); saveState(); saveSession();
  });
});

renameLineBtn.addEventListener('click', () => {
  showModal('Enter new name:', true, name => {
    if (!name) { showModal('Line name cannot be empty'); return; }
    if (lines.some((l, i) => i !== currentLineIndex && l.name === name)) {
      showModal('Line name must be unique'); return;
    }
    lines[currentLineIndex].name = name;
    updateLineSelect(); updatePreview(); saveState(); saveSession();
  });
});

lineSelect.addEventListener('change', () => {
  currentLineIndex = parseInt(lineSelect.value);
  sortPointsBtn.classList.toggle('sort-active', lines[currentLineIndex].sorted);
  updatePreview(); draw(); saveSession();
});

/**********************
 * CLEAR / TOTAL RESET
 **********************/
function performFullReset() {
  img.src = '';
  rawImageData = null;
  canvas.width = canvas.height = 0;
  axisPoints   = [];
  isCalibrated = false;
  scaleX = scaleY = offsetX = offsetY = undefined;
  logX = logY = false;
  lines         = [{ name: 'Line 1', points: [], sorted: false, orderCounter: 0 }];
  currentLineIndex = 0;
  highlightPath    = [];
  isHighlighting   = false;
  mode             = 'none';
  history          = []; historyIndex = -1;
  showGrid         = false;
  magnifierZoom    = 2;
  brightnessVal    = 100; contrastVal = 100;
  snapToLine       = false; gridFilterOn = false;
  toggleLogXBtn.classList.remove('log-active');
  toggleLogYBtn.classList.remove('log-active');
  axisInputs.style.display       = 'none';
  highlightControls.style.display= 'none';
  axisInstruction.textContent    = 'Click "Set Axis Points" then enter values.';
  brightnessSlider.value = 100; contrastSlider.value = 100;
  document.getElementById('brightness-val').textContent = '100%';
  document.getElementById('contrast-val').textContent   = '100%';
  snapToggle.checked = false; gridFilterToggle.checked = false;
  _applyCalibrationButtonState();
  undoBtn.disabled = redoBtn.disabled = true;
  sortPointsBtn.classList.remove('sort-active');
  updateLineSelect(); updatePreview(); updateButtonStates();
  localStorage.removeItem('digitizerState');
  draw();
}

clearSessionBtn.addEventListener('click', () => {
  showModal('Clear all calibration and data?', false, () => {
    performFullReset();
    showModal('Session cleared.');
  });
});

/**********************
 * EXPORT IMAGE
 **********************/
if (exportImageBtn) {
  exportImageBtn.addEventListener('click', () => {
    if (!img.src || !img.complete) { showModal('No image loaded.'); return; }
    const a   = document.createElement('a');
    a.href    = canvas.toDataURL('image/png');
    a.download= 'digitized_graph.png';
    a.click();
  });
}

/**********************
 * DATA IMPORT / EXPORT
 **********************/
importJsonBtn.addEventListener('click', () => importJsonInput.click());

importJsonInput.addEventListener('change', e => {
  showSpinner(true);
  const file = e.target.files[0];
  if (!file) { showModal('No file selected.'); showSpinner(false); return; }
  const reader = new FileReader();
  reader.onload = ev => {
    try {
      const state = JSON.parse(ev.target.result);
      lines    = state.lines    || [{ name: 'Line 1', points: [], sorted: false, orderCounter: 0 }];
      lines.forEach(line => {
        if (typeof line.sorted === 'undefined') line.sorted = false;
        if (typeof line.orderCounter === 'undefined') {
          let max = 0;
          line.points = line.points.map(p => {
            if (typeof p.order === 'undefined') p.order = ++max;
            else max = Math.max(max, p.order);
            return p;
          });
          line.orderCounter = max;
        }
      });
      axisPoints      = state.axisPoints  || [];
      scaleX          = state.scaleX;
      scaleY          = state.scaleY;
      offsetX         = state.offsetX;
      offsetY         = state.offsetY;
      logX            = state.logX        || false;
      logY            = state.logY        || false;
      isCalibrated    = state.isCalibrated|| false;
      zoom            = state.zoom        || 1;
      panX            = state.panX        || 0;
      panY            = state.panY        || 0;
      showGrid        = state.showGrid    || false;
      mode            = state.mode        || 'none';
      currentLineIndex= state.currentLineIndex || 0;
      magnifierZoom   = state.magnifierZoom    || 2;
      history = []; historyIndex = -1;
      updateLineSelect(); updatePreview(); updateButtonStates();
      toggleLogXBtn.classList.toggle('log-active', logX);
      toggleLogYBtn.classList.toggle('log-active', logY);
      document.getElementById('magnifier-zoom').value = magnifierZoom;
      highlightControls.style.display = mode === 'highlight' ? 'block' : 'none';
      axisInputs.style.display = isCalibrated ? 'none' : (mode === 'axes' && axisPoints.length > 0) ? 'block' : 'none';
      _applyCalibrationButtonState();
      sortPointsBtn.classList.toggle('sort-active', lines[currentLineIndex].sorted);
      draw(); saveState(); saveSession();
      showSpinner(false);
      showModal('JSON imported successfully.');
    } catch (err) {
      showModal('Invalid JSON file.'); console.error(err); showSpinner(false);
    }
  };
  reader.readAsText(file);
});

exportJsonBtn.addEventListener('click', () => {
  download('graph.json', JSON.stringify({
    lines, axisPoints, scaleX, scaleY, offsetX, offsetY,
    logX, logY, isCalibrated, zoom, panX, panY,
    showGrid, mode, currentLineIndex, magnifierZoom
  }), 'application/json');
});

exportCsvBtn.addEventListener('click', () => {
  let csv = '';
  lines.forEach(line => {
    csv += `"${line.name}"\nX,Y\n`;
    const pts = line.sorted
      ? [...line.points].sort((a, b) => a.dataX - b.dataX)
      : [...line.points].sort((a, b) => a.order  - b.order);
    pts.forEach(p => {
      csv += `${isNaN(p.dataX)||!isFinite(p.dataX)?'NaN':p.dataX.toFixed(15)},${isNaN(p.dataY)||!isFinite(p.dataY)?'NaN':p.dataY.toFixed(15)}\n`;
    });
    csv += '\n';
  });
  download('graph.csv', csv, 'text/csv');
});

exportXlsxBtn.addEventListener('click', () => {
  try {
    const wb  = XLSX.utils.book_new();
    const all = [];
    lines.forEach((line, idx) => {
      if (!line.points.length) return;
      all.push([line.name]);
      all.push(['X', 'Y']);
      const pts = line.sorted
        ? [...line.points].sort((a, b) => a.dataX - b.dataX)
        : [...line.points].sort((a, b) => a.order  - b.order);
      pts.forEach(p => {
        all.push([
          isNaN(p.dataX)||!isFinite(p.dataX)?'NaN':Number(p.dataX.toFixed(15)),
          isNaN(p.dataY)||!isFinite(p.dataY)?'NaN':Number(p.dataY.toFixed(15))
        ]);
      });
      if (idx < lines.length - 1) all.push([]);
    });
    if (!all.length) { showModal('No data to export.'); return; }
    const ws = XLSX.utils.aoa_to_sheet(all);
    XLSX.utils.book_append_sheet(wb, ws, 'All_Lines');
    XLSX.writeFile(wb, 'graph.xlsx');
  } catch (e) {
    showModal('Failed to export XLSX.'); console.error(e);
  }
});
